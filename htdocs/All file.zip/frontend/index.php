<?php 
include 'connect.php'; // Database connection
include 'frontend/all_iems/home.php'; // Home page
include 'frontend/all_iems/css/style.php'; // CSS styles
