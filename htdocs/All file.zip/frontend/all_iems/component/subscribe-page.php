<section style="max-width: 600px; margin: auto; padding: 30px; font-family: sans-serif;">
  <h2 style="color: #1c64f2;">সাবস্ক্রাইব করুন (Subscribe to Newsletter)</h2>

  <p>নতুন প্রোডাক্ট, অফার এবং ডিল সম্পর্কে আপডেট পেতে সাবস্ক্রাইব করুন।</p>

  <form action="#" method="post" style="display: grid; gap: 15px;">
    <input type="text" name="name" placeholder="আপনার নাম" required style="padding: 10px; width: 100%;">
    <input type="email" name="email" placeholder="আপনার ইমেইল" required style="padding: 10px; width: 100%;">
    <button type="submit" style="padding: 10px; background-color: #1c64f2; color: white; border: none; border-radius: 5px; cursor: pointer;">
      সাবস্ক্রাইব করুন
    </button>
  </form>

  <p style="margin-top: 15px;">We respect your privacy. No spam, unsubscribe any time.</p>
</section>
