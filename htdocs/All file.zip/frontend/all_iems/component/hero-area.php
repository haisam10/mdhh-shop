<div class="d-flex j-cn-cn a-i-cn hero-area">
    <div class="hero-area-img-hero animation-left">
        <div class="hero-area-image-tag">Shop t-shirt-1<button>Price: 500 BDT</button></div>
        <img src="frontend/all_iems/image/t-shirt-1.avif" alt="">
    </div>
    <div class="hero-area-img-side animation-right">
        <div>
        <img src="frontend/all_iems/image/bag-1-dark.avif" alt="">
        <div id="hero-area-image-side-tag">Shop bag-1<button>Price: 500 BDT</button></div>
        </div>
        <div>
        <img src="frontend/all_iems/image/cup-black.avif" alt="">
        <div id="hero-area-image-side-tag">Shop mug-1<button>Price: 500 BDT</button></div>
        </div>
    </div>
</div>